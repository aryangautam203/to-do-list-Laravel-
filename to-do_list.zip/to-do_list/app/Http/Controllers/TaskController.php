<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\task;
class TaskController extends Controller
{
    public function index()
    {
        $tasks = task::all();

        return view('welcome', compact('tasks'));
    }

    // Creating new task
    public function store(Request $request)
{
    $request->validate([
        'task' => 'required|unique:tasks'
    ]);

    $task = new Task;
    $task->task = $request->input('task');

    if ($task->save()) {
        return redirect('/')->with('success', 'Task created successfully.');
    } else {
        session()->flash('error', 'Failed to create task.'); // Set error message
        return redirect('/'); // Redirect back to homepage
    }
}



    // Updating the status of task
    public function updateStatus($id) {
        $task = Task::find($id);
        if($task) {
            $task->status = $task->status == 0 ? 1 : 0;
            $task->save();
            return response()->json(['success' => true, 'status' => $task->status]);
        }
        return response()->json(['success' => false]);
    }

    // Deleting task
    public function destroy($id) {
        $task = Task::find($id);
        if($task) {
            $task->delete();
            return response()->json(['success' => true]);
        }
        return response()->json(['success' => false]);
    }


    public function update(Request $request, $id)
{
    $task = Task::find($id);
    $task->task = $request->input('task');

    $task->save();

    return response()->json(['success' => true]);
}
}
