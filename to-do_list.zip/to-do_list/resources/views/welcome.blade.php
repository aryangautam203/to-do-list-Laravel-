<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>to-do list</title>
    <link rel="stylesheet" href="{{ asset('public/styles.css') }}">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        .container h1{
            text-align: center;
            margin: 5%;
            font-weight: 700;
            color: #00398d;
        }
        .container-fluid{
            background: #00398d;
        }
        nav.navbar.navbar-expand-lg.bg-body-tertiary{
            background: #00398d !important;
        }
        a.navbar-brand{
            color:#fff;
        }
        a.nav-link{
            color: #fff;
        }
        a.nav-link.active{
            color: #fff!important;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">To-Do List</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#" onclick="showAllTasks()">All Tasks</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#" onclick="showCompletedTasks()">Completed</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#" onclick="showPendingTasks()">Pending</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#addTaskModal">Add new</a>
                </li>
            </ul>

        </div>
    </div>
</nav>



<div class="container">

<h1>To-Do List App</h1>
    <table class="table table-hover" id="tasksTable">
        <thead>
        <tr>
            <th scope="col">S.No.</th>
            <th scope="col">Task</th>
            <th scope="col">Status</th>
            <th scope="col">Action</th>
        </tr>
        </thead>
        <tbody>
        @foreach($tasks as $task)
            <tr class="taskRow">
                <td>{{ $task->id }}</td>
                <td>{{ $task->task }}</td>
                <td>{{ $task->status }}</td>
                <td>
                    <a href="#" class="btn btn-sm btn-primary update-status">Update Status</a>
                    <a href="#" class="btn btn-sm btn-info edit-task" data-task-id="{{ $task->id }}">Edit</a>
                    <a href="#" class="btn btn-sm btn-danger delete-task" onclick="return confirmDelete()">Delete</a>
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>

<!-- Add Task Modal -->
<div class="modal fade" id="addTaskModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add New Task</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="addTaskForm" action="{{ route('tasks.store') }}" method="post">
                @csrf
                    <div class="mb-3">
                        <label for="task" class="form-label">Task:</label>
                        <input type="text" class="form-control" id="task" name="task" required>
                    </div>
                    <button class="btn btn-primary" type="submit">Add Task</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Edit Task Modal -->
<div class="modal fade" id="editTaskModal" tabindex="-1" aria-labelledby="editTaskModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editTaskModalLabel">Edit Task</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="editTaskForm" method="POST"> <!-- Changed method to POST -->
                @csrf
                @method('POST') <!-- Assuming you're using PUT for updating tasks -->
                    <div class="mb-3">
                        <label for="edit_task" class="form-label">Task:</label>
                        <input type="text" class="form-control" id="edit_task" name="task" required>
                        <input type="hidden" id="edit_task_id" name="task_id">
                    </div>
                    <button class="btn btn-primary" type="submit">Update Task</button>
                </form>
            </div>
        </div>
    </div>
</div>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- For update the status of task -->

<script>
    $(document).ready(function(){
        $(".update-status").click(function(e){
            e.preventDefault();
            var task_id = $(this).closest("tr").find("td:first").text(); // Assuming S.No. is the first column
            $.ajax({
                url: "{{ route('update-status', ':id') }}".replace(':id', task_id),
                type: "POST",
                dataType: "json",
                data: {
                    _token: "{{ csrf_token() }}"
                },
                success: function(response){
                    if(response.success) {
                        // Update the status in the table
                        var new_status = response.status;
                        // Assuming status is the third column
                        $(e.target).closest("tr").find("td:nth-child(3)").text(new_status);
                    } else {
                        console.log("Failed to update status.");
                    }
                },
                error: function(xhr, status, error){
                    console.error(xhr.responseText);
                }
            });
        });
    });
</script>

<!-- For Deleting the task -->

<script>
    function confirmDelete() {
        return confirm("Are you sure you want to delete this task?");
    }
</script>

<script>
    $(document).ready(function(){
        $(".delete-task").click(function(e){
            e.preventDefault();
            var task_id = $(this).closest("tr").find("td:first").text(); // Assuming S.No. is the first column
            if(confirmDelete()) {
                $.ajax({
                    url: "{{ route('tasks.destroy', ':id') }}".replace(':id', task_id),
                    type: "DELETE",
                    dataType: "json",
                    data: {
                        _token: "{{ csrf_token() }}"
                    },
                    success: function(response){
                        if(response.success) {
                            // Remove the row from the table
                            $(e.target).closest("tr").remove();
                        } else {
                            console.log("Failed to delete task.");
                        }
                    },
                    error: function(xhr, status, error){
                        console.error(xhr.responseText);
                    }
                });
            }
        });
    });
</script>

<script>
    $(document).ready(function(){
        $(".edit-task").click(function(e){
            e.preventDefault();
            var task_id = $(this).data("task-id");
            var task_name = $(this).closest("tr").find("td:nth-child(2)").text(); // Assuming Task is the second column
            $("#edit_task_id").val(task_id);
            $("#edit_task").val(task_name);
            $("#editTaskForm").attr("action", "{{ route('tasks.update', '') }}/" + task_id);
            $('#editTaskModal').modal('show');
        });
    });
</script>

<script>
    function showAllTasks() {
        $(".taskRow").show();
    }

    function showCompletedTasks() {
        $(".taskRow").hide();
        $(".taskRow:has(td:contains('1'))").show();
    }

    function showPendingTasks() {
        $(".taskRow").hide();
        $(".taskRow:has(td:contains('0'))").show();
    }
</script>


</body>
</html>
