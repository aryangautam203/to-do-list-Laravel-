<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TaskController;

Route::get('/',[Taskcontroller::class,'index'])->name('welcome');

Route::post('/tasks', [TaskController::class, 'store'])->name('tasks.store');

Route::post('/update-status/{id}', [TaskController::class, 'updateStatus'])->name('update-status');

Route::delete('/tasks/{id}', [TaskController::class, 'destroy'])->name('tasks.destroy');

Route::post('/tasks/{id}', [TaskController::class, 'update'])->name('tasks.update');

Route::get('/completed-tasks', [TaskController::class, 'completedTasks'])->name('completed-tasks');
Route::get('/pending-tasks', [TaskController::class, 'pendingTasks'])->name('pending-tasks');

